#import "GPUImageTwoInputFilter.h"

@interface GPUImageOverlayBlendFilter : GPUImageTwoInputFilter

@end
