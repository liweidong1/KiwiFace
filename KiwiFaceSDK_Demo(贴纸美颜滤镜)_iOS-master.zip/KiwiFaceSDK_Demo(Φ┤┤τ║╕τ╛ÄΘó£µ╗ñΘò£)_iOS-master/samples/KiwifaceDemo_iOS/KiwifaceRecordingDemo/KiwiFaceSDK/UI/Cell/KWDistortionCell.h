//
//  KWDistortionCell.h
//  KiwiFaceKitDemo
//
//  Created by jacoy on 17/1/12.
//  Copyright © 2017年 0dayZh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KWDistortionCell : UICollectionViewCell

@property(nonatomic ,strong)UIImageView *imgView;

- (id)initWithFrame:(CGRect)frame;

@end
